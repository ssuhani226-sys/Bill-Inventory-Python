import datetime
import read
import write

# Inventory(list of tuples)
shoes=[
    (1, "Loafer Light", "GoldStar", 200, 1000.0, "domestic"),
    (2, "Inigo 732", "Caliber", 100, 2800.0, "domestic"),
    (3, "Lite Racer", "Adidas", 200, 7000.0, "international")
    ]

'''calling function to read txt file'''
def save_inventory(shoes, filename="shoes.txt"):
    with open(filename,"w") as file:
        for s in shoes:
            file.write(",".join([str(value)for value in s]) +"\n")

def display_shoes(shoes):#to display shoes in table
    print("-" * 180)
    print(f"|{'ID' : ^25} |{'Shoe Name': ^25} |{'Brand': ^25} |{'Quantity': ^25} |{'Price': ^25} |{'Origin': ^25}|")
    print("-" * 180)
    for shoe in shoes:
        print(f"|{shoe[0]: ^25} |{shoe[1]: ^25} |{shoe[2]: ^25} |{shoe[3]: ^25} |{shoe[4]: ^25} |{shoe[5]: ^25}|")
    print("-"* 180)

'''calling function for sell part'''
def sell_shoes(shoes):
    display_shoes(shoes)
    items = []#declaring empty list
    customer_name = input("Enter customer name: ")
   
    while True:
        try:
            shoe_id = int(input("Enter the shoe ID: "))
            
            # Check if shoe ID exists
            shoe_found = False
            for shoe in shoes:
                if shoe[0] == shoe_id:
                    shoe_found = True
                    quantity = int(input("No.of shoes: "))
                    if quantity <= 0:
                        print("Quantity must be a positive number & greater than 0.")
                        continue
                    
                    if shoe[3] >= quantity:
                        items.append({
                            "shoe": shoe,
                            "quantity": quantity
                        })
                        shoe[3] -= quantity
                        print("Items purchased successfully.")
                    else:
                        print("Not enough quantity available.")
                    break
            
            if not shoe_found:
                print("Shoe ID not found.")
                
            #Ask to add more purchase
            add_more = input("Do you want to purchase more shoes? (yes/no): ")
            if add_more!= 'yes':
                break
                
        except ValueError:
            print("Invalid Shoe Id.")

         #Display PurchaseBill 
    print("\n----- SPEEDZWEAR BILL -----")
    print("Customer:", customer_name)
    print("{:<20} {:<10} {:<8} {:<10} {:<12} {:<12} {:<10}".format(
        "Shoe Name", "Brand", "Qty", "Price", "Origin", "Total", "Discount"))
    print("-" * 90)

    gross = 0
    total_discount = 0
    net = 0

    for item in items:
        shoe = item["shoe"]
        quantity = item["quantity"]

        item_total = shoe[4] * quantity
        discount = 0.0
        if quantity > 10:#discount condition
            discount = 0.05
            if shoe[5] == "domestic":
                discount = 0.07

        discount_amount = item_total * discount
        final_price = item_total - discount_amount

        gross += item_total
        total_discount += discount_amount
        net += final_price

        print("{:<20} {:<10} {:<8} {:<10} {:<12} {:<12} {:<10}".format(
            shoe[1], shoe[2], quantity, shoe[4], shoe[5], item_total, discount_amount))

    print("-" * 90)
    print("Gross Total: Rs", gross)
    print("Total Discount: Rs", total_discount)
    print("Net Payable: Rs", net)
    print("=" * 90)
      
    #generate invoice(for 0 items too)
    generate_sales_invoice(customer_name, items)
    print("Purchase is made successfully!")
    
'''calling function for restock option'''    
def restock_shoes(shoes_data):
    display_shoes(shoes_data)
    items = []
    supplier_name = input("Enter supplier name: ")
    
    while True:
        try:
            shoe_id = int(input("Enter shoe ID for restock: "))
            
            shoe_found = False
            for shoe in shoes_data:#check if the shoe Id exists
                if shoe[0] == shoe_id:
                    shoe_found = True
                    quantity = int(input("Enter the quantity: "))
                    if quantity <= 0:
                        print("Quantity must be a positive number and greater than 0.")
                        continue
                    
                    items.append({
                        "shoe": shoe,
                        "quantity": quantity
                    })
                    shoe[3] += quantity
                    print("Items updated for restock successfully!")
                    break
            
            if not shoe_found:
                print("Shoe not found in the stock.")
                
            #To add more items
            add_more = input("Do you want to add more items? (yes/no): ")
            if add_more!= 'yes':
                break#again starts from beginning
                
        except:
            print("Invalid Input.")
            
    generate_restock_invoice(supplier_name, items)
    print("Items will be restocked soon!")#message after input


def generate_sales_invoice(customer_name, items):
    '''to generate bill including tax, invoice and VAT'''
    today = datetime.datetime.today()
    year = today.year
    month = today.month
    day = today.day
    hour = today.hour
    minute = today.minute
    second = today.second
    
    
    filename = f"{customer_name}_{month}{day}_{hour}{minute}{second}.txt"
    
    #initialise
    total_discount = 0
    total_vat = 0
    grand_total = 0
    subtotal = 0
    
    with open(filename, "w") as file:
        file.write("=" * 96 + "\n")
        file.write("SPEEDZWEAR VAT INVOICE\n")
        file.write("=" * 96 + "\n")
        file.write("Customer: " + customer_name + "\n")
        file.write("Date: " + str(year) + "-" + str(month) + "-" + str(day) + " " + str(hour) + ":" + str(minute) + ":" + str(second) + "\n")

        file.write("-" * 96  + "\n")
        file.write("Items Purchased:\n")
        file.write("-" * 96 + "\n")
        
        if not items:
            file.write("No items purchased.\n")
        else:
            for item in items:
                shoe = item["shoe"]
                quantity = item["quantity"]
                item_total = shoe[4] * quantity
                discount = 0.0
                #for greater than 10 quantity, discount is applied
                if quantity > 10:
                    discount = 0.05
                    if shoe[5] == "domestic":
                        discount = 0.07
                '''discount amount calculation'''
                discount_amount = item_total * discount
                item_subtotal = item_total - discount_amount
                item_vat = item_subtotal * 0.13
                item_final = item_subtotal + item_vat
                
                total_discount += discount_amount
                total_vat += item_vat
                grand_total += item_final
                subtotal += item_total
                #invoice with discount amount
                file.write("Shoe: " + shoe[1] + " (" + shoe[2] + ")\n")
                file.write("Quantity: " + str(quantity) + " | Unit Price: Rs " + str(shoe[4]) + "\n")
                file.write("Item Total: Rs " + str(item_total) + "\n")
                if discount_amount > 0:
                    file.write("Discount: " + str(discount*100) + "% (Rs " + str(discount_amount) + ")\n")
                file.write("VAT: Rs " + str(item_vat) + "\n")
                file.write("Item Final: Rs " + str(item_final) + "\n")
                file.write("-" * 30 + "\n")
        
        file.write("=" * 60 + "\n")
        file.write("SUMMARY:\n")
        file.write("Subtotal: Rs " + str(subtotal) + "\n")
        file.write("Total Discount: Rs " + str(total_discount) + "\n")
        file.write("Total VAT (13%): Rs " + str(total_vat) + "\n")
        file.write("GRAND TOTAL: Rs " + str(grand_total) + "\n")
        file.write("=" * 60 + "\n")
        file.write("Thank you! Do Visit Us Again.\n")
        file.write("=" * 60 + "\n")
    
    print("Invoice generated: " + filename)
    
'''calling fucntion to generate restock invoice'''
def generate_restock_invoice(supplier_name, items):
    today = datetime.datetime.today()
    year = today.year
    month = today.month
    day = today.day
    hour = today.hour
    minute = today.minute
    second = today.second
    
    #restock file
    filename = f"restock_{supplier_name}_{month}{day}_{hour}{minute}{second}.txt"
    
    total_vat = 0
    grand_total = 0
    subtotal = 0
    
    with open(filename, "w") as file:
        file.write("=" * 60 + "\n")
        file.write("SPEEDZWEAR RESTOCK INVOICE\n")
        file.write("=" * 60 + "\n")
        file.write("Supplier: " + supplier_name + "\n")
        file.write("Date: " + str(year) + "-" + str(month) + "-" + str(day) + " " + str(hour) + ":" + str(minute) + ":" + str(second) + "\n")
        file.write("-" * 60 + "\n")
        file.write("Items Restocked:\n")
        file.write("-" * 60 + "\n")
        
        if not items:#checks the item
            file.write("Sorry, no items for restock!\n")
            print("Sorry,no items for restock!")
        else:
            for item in items:
                shoe = item["shoe"]
                quantity = item["quantity"]
                '''calculates amount for bill'''
                item_total = shoe[4] * quantity
                item_vat = item_total * 0.13
                item_final = item_total + item_vat
                
                total_vat += item_vat
                grand_total += item_final
                subtotal += item_total
                
                for line in[
                    f"Shoe: {shoe[1]}({shoe[2]})",
                    f"Quantity: {quantity} | Unit Price: Rs {shoe[4]}",
                    f"Item Subtotal: Rs {item_total}",
                    f"VAT: Rs {item_vat}",
                    f"Item Total: Rs {item_final}",
                    "-" * 30
                ]:
                    file.write(line+"\n")
                    print(line)
        for line in[
             "=" * 60,
        "-----RESTOCK INVOICE:------",
        f"Subtotal: Rs {subtotal}",
        f"Total VAT (13%): Rs {total_vat}",
        f"GRAND TOTAL: Rs {grand_total}",
        "=" * 60,
        "=" * 60
        ]:
            file.write(line+"\n")
            print(line)
            
    print("Thank you for shopping!")
            
    print("Restock invoice in: " + filename)
