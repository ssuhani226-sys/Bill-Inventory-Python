def update_data(shoes_data):
    try:
        with open("shoes.txt", "w") as file:
            for shoe in shoes_data:
                line = f"{shoe[0]},{shoe[1]},{shoe[2]},{shoe[3]},{shoe[4]},{shoe[5]}\n"
                file.write(line)
        print("Data updated in file successfully.")
    except Exception as e:
        print(f"Error, file not found: {e}")
