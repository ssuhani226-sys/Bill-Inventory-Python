import datetime
from read import read_shoes_data
import operation
import write
'''calling function'''
def main():
    print("<-----SpeedzWear Wholesale Store!------>")
    
    while True:
        shoes_data = read_shoes_data()#reads from the shoes_data list
        print("""
        1. Display all shoes
        2. Sell shoes
        3. Restock shoes
        4. Exit
        """)
        
        try: 
            user_input = int(input("Enter your choice: "))
            
            if user_input == 1:
                operation.display_shoes(shoes_data)
            elif user_input == 2:
                operation.sell_shoes(shoes_data)
                write.update_data(shoes_data)
            elif user_input == 3:
                operation.restock_shoes(shoes_data)
                write.update_data(shoes_data)
            elif user_input == 4:
                print("Thank you for using SpeedzWear system.")
                break
            else:
                print("Please choose from options 1-4.")
                continue  
        except:
            print("Invalid input.")
            continue  
        
        # Ask if user wants to continue 
        while True:
            continue_choice = input("\nDo you want to continue? (yes/no): ")
            if continue_choice in ['yes', 'no']:
                break
            else:
                print("Please enter an option.")
        
        if continue_choice != 'yes': #for no option
            print("Thank you! Do Visit Us Again.")
            break

main()
