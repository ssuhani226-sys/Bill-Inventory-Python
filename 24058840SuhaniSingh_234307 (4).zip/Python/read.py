def read_shoes_data(filename="shoes.txt"):#reads the shoe data
    shoes_data = []#empty list
    try:
        with open("shoes.txt","r") as file:
            for line in file:#line is an object for the file
                parts = line.replace("\n","").split(",")
                shoe = [int(parts[0]),
                        (parts[1]),
                        (parts[2]),
                        int(parts[3]), 
                        float(parts[4]), parts[5]]
                shoes_data.append(shoe)#adds shoe list the empty list
    except:
        print("Error: File not found.")
    return shoes_data
data = read_shoes_data()
print(data)
